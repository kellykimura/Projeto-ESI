# Ghibli No Tana

O exemplar é rodado no console.

O caso de uso de alto nível e o de caso expandido estão no mesmo arquivo drawio mas em páginas diferentes.

Para simplificar nossas ideias, temos a prototipação visual inicial no figma: https://www.figma.com/design/uNw80uJxq0bM4uduCHbqCE/Ghibli?t=ViDssoDLZztJnexk-1

Feito por Gabrielly Christina Moreira e Kelly Akari Kimura
